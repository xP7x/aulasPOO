<?php
if (isset($_GET['sucesso']) && $_GET['sucesso'] == 'true') {
  ?>
  <script>
    setTimeout(function() {
      window.location.href = 'index.php';
    }, 3000); // Redireciona após 3 segundos
  </script>
  <div class="alert alert-success" role="alert">
    Cadastrado com Sucesso!
  </div>
<?php
} else {
  // Se houver erro, exibe a mensagem de erro
  if (isset($_GET['erro'])) {
    ?>
    <div class="alert alert-danger" role="alert">
      <?= $_GET['erro'] ?>
    </div>
  <?php
  }
}
?>
<?php
require_once __DIR__ . '/php/config.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $query = "SELECT * FROM users WHERE email = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetchAll();

    if (count($result) > 0) {
        $stored_hash = $result[0]['senha']; // recupera o hash armazenado do banco de dados
        if (password_verify($senha, $stored_hash)) {
            header("location: home.php");
            exit();
        } else {
            echo "Email ou senha incorretos";
        }
    } else {
        echo "Email ou senha incorretos";
    }
}

?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Login</h5>
                <form method="post">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="password" name="senha">
                    </div>
                    <button type="submit" class="btn btn-primary">Entrar <i
                            class="bi bi-box-arrow-in-right"></i></button>
                    <a href="php\cadastro.php" class="btn btn-primary">Cadastre-se</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.10/dist/sweetalert2.all.min.js"></script>
</body>

</html>
document.addEventListener("DOMContentLoaded", function() {
  const formCadastro = document.getElementById("formCadastro");
  const nomeInput = document.getElementById("nome");
  const emailInput = document.getElementById("email");
  const senhaInput = document.getElementById("senha");

  formCadastro.addEventListener("submit", function(event) {
    event.preventDefault();

    const nome = nomeInput.value.trim();
    const email = emailInput.value.trim();
    const senha = senhaInput.value.trim();

    // Validação 1: Verificar se todos os campos estão preenchidos
    if (nome === "" || email === "" || senha === "") {
      alert("Preencha todos os campos!");
      return false; // Adicionei isso
    }

    // Validação 2: Verificar se o email está no formato correto
    if (!validateEmail(email)) {
      alert("Email inválido!");
      emailInput.focus();
      return false; // Adicionei isso
    }

    // Validação 3: Verificar se a senha tem pelo menos 8 caracteres
    if (senha.length < 8) {
      alert("A senha deve ter pelo menos 8 caracteres!");
      senhaInput.focus();
      return false; 
    }

    // Se todas as validações passarem, submeter o formulário
    formCadastro.submit();
  });

  function validateEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  }

  // Verificar se o parâmetro de sucesso foi passado na URL
  if (window.location.search.includes('sucesso=true')) {
    // Exibir popup de sucesso
    Swal.fire({
      title: 'Cadastro realizado com sucesso!',
      text: 'Você foi cadastrado com sucesso! Agora você pode fazer login.',
      icon: 'success',
      confirmButtonText: 'Ok',
    });
  }
});
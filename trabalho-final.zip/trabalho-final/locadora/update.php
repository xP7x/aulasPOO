<?php
require_once 'config.php';

if(isset($_GET["id"]) &&!empty(trim($_GET["id"]))){
    $id = trim($_GET["id"]);
    $query = "SELECT * FROM jogos WHERE id = '$id'";
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) == 1){
        $titulo = $row['titulo'];
        $plataforma = $row['plataforma'];
        $data_lancamento = $row['data_lancamento'];
        $preco = $row['preco'];
    } else{
        header("location: error.php");
        exit();
    }
} else{
    header("location: error.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $titulo = $_POST['titulo'];
    $plataforma = $_POST['plataforma'];
    $data_lancamento = $_POST['data_lancamento'];
    $preco = $_POST['preco'];

    $query = "UPDATE jogos SET titulo =?, plataforma =?, data_lancamento =?, preco =? WHERE id =?";
    $stmt = mysqli_prepare($link, $query);
    mysqli_stmt_bind_param($stmt, "ssssi", $titulo, $plataforma, $data_lancamento, $preco, $id);
    mysqli_stmt_execute($stmt);

    header("location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar jogo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="wrapper">
        <h2>Atualizar jogo</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
            <div class="form-group">
                <label>Título</label>
                <input type="text" name="titulo" class="form-control" value="<?php echo $titulo;?>">
            </div>
            <div class="form-group">
                <label>Plataforma</label>
                <input type="text" name="plataforma" class="form-control" value="<?php echo $plataforma;?>">
            </div>
            <div class="form-group">
                <label>Data de Lançamento</label>
                <input type="date" name="data_lancamento" class="form-control" value="<?php echo $data_lancamento;?>">
            </div>
            <div class="form-group">
                <label>Preço</label>
                <input type="number" name="preco" class="form-control" value="<?php echo $preco;?>">
            </div>
            <input type="submit" class="btn btn-primary" value="Atualizar">
        </form>
    </div>
</body>
</html>
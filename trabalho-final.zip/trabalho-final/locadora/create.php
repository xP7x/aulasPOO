<?php
require_once 'config.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $titulo = $_POST['titulo'];
    $plataforma = $_POST['plataforma'];
    $data_lancamento = $_POST['data_lancamento'];
    $preco = $_POST['preco'];

    $query = "INSERT INTO jogos (titulo, plataforma, data_lancamento, preco) VALUES ('$titulo', '$plataforma', '$data_lancamento', '$preco')";
    mysqli_query($link, $query);

    header("location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Criar novo jogo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="wrapper">
        <h2>Criar novo jogo</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
            <div class="form-group">
                <label>Título</label>
                <input type="text" name="titulo" class="form-control">
            </div>
            <div class="form-group">
                <label>Plataforma</label>
                <input type="text" name="plataforma" class="form-control">
            </div>
            <div class="form-group">
                <label>Data de Lançamento</label>
                <input type="date" name="data_lancamento" class="form-control">
            </div>
            <div class="form-group">
                <label>Preço</label>
                <input type="number" name="preco" class="form-control">
            </div>
            <input type="submit" class="btn btn-primary" value="Criar">
        </form>
    </div>
</body>
</html>
<?php
require_once 'config.php';

if (isset($_GET["id"]) &&!empty(trim($_GET["id"]))) {
    $id = trim($_GET["id"]);
    $query = "DELETE FROM clientes WHERE id = '$id'";
    mysqli_query($link, $query);

    header("location: clientes.php");
    exit();
} else {
    header("location: error.php");
    exit();
}
?>
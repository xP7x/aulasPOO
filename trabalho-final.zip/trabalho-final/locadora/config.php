<?php
/* Credenciais do banco de dados */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'locadora');

/* Conexão com o banco de dados */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Verificar conexão
if($link === false){
    die("ERRO: Não foi possível conectar. ". mysqli_connect_error());
}
?>
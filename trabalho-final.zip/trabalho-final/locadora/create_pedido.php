<?php
require_once 'config.php';

if (isset($_POST['submit'])) {
    $jogo_id = $_POST['jogo_id'];
    $cliente_id = $_POST['cliente_id'];
    $data_aluguel = $_POST['data_aluguel'];
    $data_devolucao = $_POST['data_devolucao'];

    $query = "INSERT INTO alugueis (jogo_id, cliente_id, data_aluguel, data_devolucao) VALUES (?, ?, ?, ?)";
    $stmt = $link->prepare($query);
    $stmt->bind_param("iiis", $jogo_id, $cliente_id, $data_aluguel, $data_devolucao);

    if ($stmt->execute()) {
        header("Location: pedidos.php");
    } else {
        echo "Erro ao cadastrar pedido: " . $link->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Pedido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/[email protected]/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
      .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Cadastrar Pedido</h2>
        <p><a href="pedidos.php" class="btn btn-primary">Voltar à lista de pedidos</a></p>
        <form method="post" action="">
            <div class="form-group">
                <label for="jogo_id">Jogo</label>
                <select name="jogo_id" id="jogo_id" class="form-control">
                    <?php
                    $query = "SELECT * FROM jogos";
                    $result = mysqli_query($link, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='{$row['id']}'>{$row['titulo']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="cliente_id">Cliente</label>
                <select name="cliente_id" id="cliente_id" class="form-control">
                    <?php
                    $query = "SELECT * FROM clientes";
                    $result = mysqli_query($link, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="data_aluguel">Data de Aluguel</label>
                <input type="date" name="data_aluguel" id="data_aluguel" class="form-control">
            </div>
            <div class="form-group">
            <div class="form-group">
                <label for="data_devolucao">Data de Devolução</label>
                <input type="date" name="data_devolucao" id="data_devolucao" class="form-control">
            </div>
            <button type="submit" name="submit" class="btn btn-success">Cadastrar Pedido</button>
        </form>
    </div>
</body>
</html>
               
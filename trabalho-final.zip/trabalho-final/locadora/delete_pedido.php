<?php
require_once 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM alugueis WHERE id =?";
    $stmt = $link->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: pedidos.php");
    } else {
        echo "Erro ao excluir pedido: ". $link->error;
    }

    $stmt->close();
}
?>
<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pedidos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/[email protected]/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
     .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <div class="wrapper">
        <h2>Pedidos</h2>
        <p><a href="create_pedido.php" class="btn btn-success">Cadastrar novo pedido</a></p>
        <p><a href="index.php" class="btn btn-primary">Voltar à página inicial</a></p>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Jogo</th>
                    <th>Data de Aluguel</th>
                    <th>Data de Devolução</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT a.id, c.nome as cliente_nome, j.titulo as jogo_titulo, a.data_aluguel, a.data_devolucao FROM alugueis a INNER JOIN clientes c ON a.cliente_id = c.id INNER JOIN jogos j ON a.jogo_id = j.id";
                $result = mysqli_query($link, $query);
                while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><?php echo $row['cliente_nome'];?></td>
                    <td><?php echo $row['jogo_titulo'];?></td>
                    <td><?php echo $row['data_aluguel'];?></td>
                    <td><?php echo $row['data_devolucao'];?></td>
                    <td>
                        <a href="update_pedido.php?id=<?php echo $row['id'];?>" class="btn btn-primary" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                        <a href="delete_pedido.php?id=<?php echo $row['id'];?>" class="btn btn-danger" data-toggle="tooltip" title="Excluir"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php }?>
            </tbody>
        </table>
    </div>
</body>
</html>
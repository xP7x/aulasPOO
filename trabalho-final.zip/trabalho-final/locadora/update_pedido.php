<?php
require_once 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT a.id, c.nome as cliente_nome, j.titulo as jogo_titulo, a.data_aluguel, a.data_devolucao FROM alugueis a INNER JOIN clientes c ON a.cliente_id = c.id INNER JOIN jogos j ON a.jogo_id = j.id WHERE a.id = ?";
    $stmt = $link->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (isset($_POST['submit'])) {
        $data_aluguel = $_POST['data_aluguel'];
        $data_devolucao = $_POST['data_devolucao'];

        $query = "UPDATE alugueis SET data_aluguel = ?, data_devolucao = ? WHERE id = ?";
        $stmt = $link->prepare($query);
        $stmt->bind_param("ssi", $data_aluguel, $data_devolucao, $id);

        if ($stmt->execute()) {
            header("Location: pedidos.php");
        } else {
            echo "Erro ao atualizar pedido: ". $link->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Pedido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="wrapper">
        <h2>Atualizar Pedido</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $id;?>" method="post">
            <div class="form-group">
                <label for="data_aluguel">Data de Aluguel</label>
                <input type="date" name="data_aluguel" id="data_aluguel" class="form-control" value="<?php echo $row['data_aluguel'];?>">
            </div>
            <div class="form-group">
                <label for="data_devolucao">Data de Devolução</label>
                <input type="date" name="data_devolucao" id="data_devolucao" class="form-control" value="<?php echo $row['data_devolucao'];?>">
            </div>
            <button type="submit" name="submit" class="btn btn-success">Atualizar Pedido</button>
            <a href="pedidos.php" class="btn btn-primary">Voltar à lista de pedidos</a>
        </form>
    </div>
</body>
</html>
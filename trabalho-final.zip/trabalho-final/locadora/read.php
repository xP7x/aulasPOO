<?php
require_once 'config.php';

if(isset($_GET["id"]) &&!empty(trim($_GET["id"]))){
    $id = trim($_GET["id"]);
    $query = "SELECT * FROM jogos WHERE id = '$id'";
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) == 1){
        $titulo = $row['titulo'];
        $plataforma = $row['plataforma'];
        $data_lancamento = $row['data_lancamento'];
        $preco = $row['preco'];
    } else{
        header("location: error.php");
        exit();
    }
} else{
    header("location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do jogo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="wrapper">
        <h2>Detalhes do jogo</h2>
        <p>
            <strong>Título:</strong> <?php echo $titulo;?>
            <br>
            <strong>Plataforma:</strong> <?php echo $plataforma;?>
            <br>
            <strong>Data de Lançamento:</strong> <?php echo $data_lancamento;?>
            <br>
            <strong>Preço:</strong> <?php echo $preco;?>
        </p>
        <p><a href="index.php" class="btn btn-primary">Voltar</a></p>
    </div>
</body>
</html>
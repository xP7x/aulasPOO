<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Locadora de Jogos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/[email protected]/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
      .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <div class="wrapper">
        <h2>Locadora de Jogos</h2>
        <p><a href="create.php" class="btn btn-success">Criar novo jogo</a></p>
        <p><a href="clientes.php" class="btn btn-primary">Ver clientes</a></p>
        <p><a href="pedidos.php" class="btn btn-info">Ver pedidos</a></p>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Plataforma</th>
                    <th>Data de Lançamento</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once 'config.php';
                $query = "SELECT * FROM jogos";
                $result = mysqli_query($link, $query);
                while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><?php echo $row['titulo'];?></td>
                    <td><?php echo $row['plataforma'];?></td>
                    <td><?php echo $row['data_lancamento'];?></td>
                    <td><?php echo $row['preco'];?></td>
                    <td>
                        <a href="read.php?id=<?php echo $row['id'];?>" class="btn btn-info" data-toggle="tooltip" title="Ver detalhes"><i class="fa fa-eye"></i></a>
                        <a href="update.php?id=<?php echo $row['id'];?>" class="btn btn-primary" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                        <a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger" data-toggle="tooltip" title="Excluir"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php }?>
            </tbody>
        </table>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Clientes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/[email protected]/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
     .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Clientes</h2>
        <p><a href="create_cliente.php" class="btn btn-success">Cadastrar novo cliente</a></p>
        <p><a href="index.php" class="btn btn-primary">Voltar à página inicial</a></p>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once 'config.php';
                $query = "SELECT * FROM clientes";
                $result = mysqli_query($link, $query);
                while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><?php echo $row['nome'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['telefone'];?></td>
                    <td>
                        <a href="update_cliente.php?id=<?php echo $row['id'];?>" class="btn btn-primary" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                        <a href="delete_cliente.php?id=<?php echo $row['id'];?>" class="btn btn-danger" data-toggle="tooltip" title="Excluir"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php }?>
            </tbody>
        </table>
    </div>
</body>
</html>